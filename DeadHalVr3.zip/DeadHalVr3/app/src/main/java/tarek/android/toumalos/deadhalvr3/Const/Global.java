package tarek.android.toumalos.deadhalvr3.Const;

public class Global {
    public final static String ROTATE ="ROTATE";
    public final static String REMOVE ="REMOVE";
    public final static String ADD ="ADD";
    public final static String MOOVE ="MOOVE";
    public final static String ZOOM ="ZOOM";
    public final static String RESIZE ="RESIZE";
    public final static String TAG ="Flaki";
    public final static String RELATION ="RELATION";
    public final static String NOTHING ="";

}
