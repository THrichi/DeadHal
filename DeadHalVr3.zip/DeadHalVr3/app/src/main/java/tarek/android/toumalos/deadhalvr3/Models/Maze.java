package tarek.android.toumalos.deadhalvr3.Models;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

public class Maze {
    private String UID;
    private String name;
    private List<Rectangle> rectangles;
    private List<Line> lines;

    public Maze() {
        rectangles = new ArrayList<>();
        lines = new ArrayList<>();
    }

    public Maze(String name, List<Rectangle> rectangles, List<Line> lines) {
        UUID uuid = UUID.randomUUID();
        this.UID = uuid.toString();
        this.name = name;
        this.rectangles = rectangles;
        this.lines = lines;
    }

    public String getUID() {
        return UID;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public List<Rectangle> getRectangles() {
        return rectangles;
    }

    public void setRectangles(List<Rectangle> rectangles) {
        this.rectangles = rectangles;
    }

    public List<Line> getLines() {
        return lines;
    }

    public void setLines(List<Line> lines) {
        this.lines = lines;
    }
}
